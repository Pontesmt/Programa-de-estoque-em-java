/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class Pecas {
    String NomePeca, LocalPeca;
    double PrecoPeca;
    public Pecas(String fn, double fp, String fl){
        this.NomePeca = fn;
        this.LocalPeca = fl;
        this.PrecoPeca = fp;
    }
}
