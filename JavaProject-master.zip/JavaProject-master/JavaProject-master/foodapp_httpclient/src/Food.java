public class Food {
    int foodid;
    String foodname,fooddesc;
    double foodprice;
    public Food(int foodid, String foodname,double foodprice,String fooddesc){
        this.foodid = foodid;
        this.foodname = foodname;
        this.foodprice = foodprice;
        this.fooddesc = fooddesc;
    }
}